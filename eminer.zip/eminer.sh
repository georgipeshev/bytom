#!/usr/bin/env bash

export GPU_MAX_HEAP_SIZE=100
export GPU_USE_SYNC_OBJECTS=1
export GPU_SINGLE_ALLOC_PERCENT=100
export GPU_MAX_ALLOC_PERCENT=100

[[ ! -e ./eminer.conf ]] && echo "No eminer.conf, exiting" && exit 1

conf=`cat ./eminer.conf | grep -v "^$" | grep -v "^#"`

#echo $conf outputs all in one line
echo $conf
./eminer `echo $conf` 2>&1 | tee /var/log/miner/eminer/eminer.log
